/**
 * Created by Administrator on 2016/9/29.
 */
class Tab{
    constructor(ids){
        this.ids = ids

    }

    tabs(){
        console.log(this)
        var $this = $( '.' + this.ids),
            $spans = $this.children('.tab').find('span'),
            $uls = $this.children('.con').find('ul')
        $spans.each(function(index){
            $(this).mouseover(function(){
                $(this).addClass('on').siblings().removeClass('on')
            })
            $uls.eq(index).css('display', 'block').siblings().css('display', 'none')
        })




    }
}

function tabs(ids){
    this.ids = ids
}
tab.prototype.tab = function(){

}


window.onload = function(){
    new Tab('tabs').tabs()
}
