/**
 * Created by Administrator on 2016/9/27.
 */
//点击的时候，图片切换至上一张或者下一张
//下一张
//$('.sld-next').click(function(){
//    $('.sld-move').animate({
//        top:-95
//    }, 500, function(){
//        $('.sld-move').css('top', 0).children().first().appendTo( $('.sld-move') )
//    })
//})
////上一张
//$('.sld-pre').click(function(){
//    $('.sld-move').css('top', '-95px').children().last().prependTo($('.sld-move'))
//    $('.sld-move').animate({
//        top:0
//    })
//})

//水平方向
$('.sld-next').click(function(){
    $('.sld-move').stop(true,true).animate({
        left:-160
    }, 500, function(){
        $('.sld-move').css('left', 0).children().first().appendTo( $('.sld-move') )
    })
})

$('.sld-pre').click(function(){
    $('.sld-move').css('left', '-160px').children().last().prependTo($('.sld-move'))
    $('.sld-move').stop(true,true).animate({
        left:0
    }, 500)
})

