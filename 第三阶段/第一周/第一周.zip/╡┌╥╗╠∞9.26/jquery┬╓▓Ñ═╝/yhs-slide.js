/**
 * Created by Administrator on 2016/9/26.
 */
// 解决从右向左的平移：left ，值怎么获取？
$(function(){
    var lis = $('.yh-slide ul').find('li')
//    获取定位元素的偏移量
    lis.each(function(index){
        //console.log(index)
        //var ins = index + 1
        //console.log( lis.eq(index).position().left )
        if( index == 0 ){
            lefts = lis.last().position().left
        } else {
            lefts = lis.eq(index - 1).position().left
        }
        //lefts = $(this).position().left
        console.log(lefts)
    //当前元素的Left为上一个元素的,即5用4,4用3,当为1的时候，值为5的
        $(this).stop().animate({
            left:lefts 
        }, 1000)

    })


})