/**
 * Created by Administrator on 2016/9/26.
 */
//一个页面内部可以写多个轮播图，即多次调用某个Js文件，也可自定义速度,那么就需要两个参数，一个参数决定当前调用插件的标签，一个参数决定动画的速度
$.fn.yhslide = function( options ){
    //console.log($(this))
    //console.log(this)
    this.each(function(i , ele){
        yslide(ele, options)
    })
    return this

}

    var yslide = function(ele, options) {

        //设置默认的循环时间间隔以及动画执行的时间
        var defspd = $.extend({
            delay:3000,
            speed:1000
        }, options)

        var $ele = $(ele)
        var lis = $ele.find('li')
        console.log(lis)

    var lisCss = [
        { width:100, height:150, left:150, top:68, $zIndex:1, $opacity:0.4 },
        { width:150, height:170, left:0, top:75, $zIndex:2, $opacity:0.5 },
        { width:200, height:230, left:120, top:45, $zIndex:3, $opacity:0.6 },
        { width:240, height:320, left:290, top:0, $zIndex:4, $opacity:1 },
        { width:200, height:230, left:500, top:45, $zIndex:3, $opacity:0.6 },
        { width:150, height:170, left:670, top:75, $zIndex:2, $opacity:0.5 },
        { width:100, height:150, left:520, top:68, $zIndex:1, $opacity:0.4 }
    ]

    function move(){
        lis.each(function(ins){
            $(this).css('zIndex',lisCss[ins].$zIndex).stop(true,true).animate(lisCss[ins], defspd.speed).find('img').css('opacity', lisCss[ins].$opacity)
        })
    }
//    如何把数组元素的最后一个元素放置在第一个元素的位置上？
//    下一张
    function next(){
        lisCss.unshift( lisCss.pop() )
        move()
    }

    //上一张
    function prev(){
        lisCss.push( lisCss.shift() )
        move()
    }

    function play(){
        inters = setInterval(next, defspd.delay)
    }
    //停止循环
    function stop(){
        clearInterval(inters)
    }
    //切换上一张
    $('.slides section:first-of-type').click(function(){
        stop()
        prev()
        play()
    })
    //切换下一张
    $('.slides section:last-of-type').click(function(){
        stop()
        next()
        play()
    })
    //首先初始化当前页面样式
    move()
    //自动播放下一张
    play()
}
