//引入相关模块
const express = require('express'),
      bodyParser = require('body-parser'),
      cookieParser = require('cookie-parser'),
      fs = require('fs'),
      template = require('art-template')
//  实例化模块
var app = express()
//  设置中间件
//app.use( express.static('www') )
app.use( bodyParser.urlencoded({ extended:false }) )
app.use( cookieParser() )

//设置视图引擎
app.engine('.html', template.__express)
app.set('view engine', 'html')

template.config('cache', false)

/*--------------  注册  --------------*/
app.post('/user/register', function(req, res){
    console.log( req.body )      // 输出请求的内容
    req.body.ip = req.ip
    req.body.time = new Date()

    function send(code, message){
        res.status(200).json({code, message})
    }

    function saveFile(){
        var fileName = 'user/' + req.body.uname + '.txt'
        fs.exists(fileName, function(ex){
            if(ex){
                send('registered', '该用户已注册')
            } else {
                fs.appendFile(fileName, JSON.stringify( req.body ), function(err){
                    if(err){
                        send('file error', '文件系统错误')
                    } else {
                        send('success', '恭喜，已注册成功，请登录...')
                    }
                })
            }
        })

    }

//    判断存储用户名信息的文件夹是否存在
    fs.exists('user', function(ex){
        if( !ex ){
            fs.mkdirSync('user')
        //    保存文件---用户信息
            saveFile()

        } else {
        //    保存文件---用户信息
            saveFile()
        }
    })

})


/*-----------------  登录  -----------*/
app.post('/user/login', function(req, res){
    console.log( req.body )
    var uname = req.body.uname

    function send(code, message){
        res.status(200).json({code, message})
    }

//    判断用户名是否存在
    var fileName = 'user/' + uname + '.txt'

    fs.exists(fileName, function(ex){
        if( !ex ){
            send('error', '用户不存在')
        } else {
        //    判断用户密码是否匹配----读当前文件的密码
            fs.readFile(fileName, function(err, data){
                if(err){
                    send('file error', '文件系统错误')
                } else {
                    var datas = JSON.parse(data)
                    var password = datas.pwd
                    if( password == req.body.pwd ){
                        res.cookie('uname', uname)
                        send('success', '用户登录成功')
                    } else {
                        send('pwd error', '用户名或密码错误')
                    }
                }
            })
        }
    })

})

// 退出
app.get('/signout', function(req, res){
    res.clearCookie('uname')
    res.status(200).json({code:'success'})
})

//保存留言信息
app.post('/message', function(req, res){
    console.log( req.body )
    req.body.username = req.cookies.uname
    req.body.time = new Date()
    req.body.ip = req.ip
//    保存留言信息
    fs.exists('message', function(ex){
        if( !ex ){
            fs.mkdirSync('message')
            fs.appendFile('message/text.txt', JSON.stringify(req.body), function(err){
                if(err){
                    res.status(200).json({code:'error', message:'保存数据失败'})
                } else {
                    res.status(200).json({code:'success', message:'留言提交成功'})
                }
            })
        } else {
            fs.appendFile('message/text.txt', JSON.stringify(req.body), function(err){
                if(err){
                    res.status(200).json({code:'error', message:'保存数据失败'})
                } else {
                    res.status(200).json({code:'success', message:'留言提交成功'})
                }
            })
        }


    })
})

//  读取留言信息
app.get('/', function(req, res){
    fs.exists('message/text.txt', function(ex){
        if(!ex){
            res.send('当前不存在该留言')
        } else {
            fs.readFile('message/text.txt', function(err, data){
                if(err){
                    res.send('文件错误')
                } else {
                    //console.log(JSON.parse(data))
                    var message = {mess:[], title:'留言板名称'}
                    //console.log(message)
                    var datas = JSON.parse(data)

                    message.mess.push(datas)
                    //console.log(message.mess)
                    console.log(message)
                    var arrs = message.mess
                    console.log(arrs)
                    res.render('index', {datas:arrs})

                }
            })
        }
    })
})

//监听端口
app.listen(2000, function(){
    console.log( 'nodejs is running' )
})






