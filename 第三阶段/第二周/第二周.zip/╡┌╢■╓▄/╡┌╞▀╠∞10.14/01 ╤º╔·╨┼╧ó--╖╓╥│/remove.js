/**
 * Created by Administrator on 2016/10/12.
 */
//删除功能
var express = require('express'),
    studb = require('./studb')
var router = express.Router()

router.get('/', function(){


})

module.exports = router