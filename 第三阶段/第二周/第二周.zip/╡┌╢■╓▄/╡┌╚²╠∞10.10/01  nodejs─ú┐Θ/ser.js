/**
 * Created by Administrator on 2016/10/10.
 */
var result = require('./app')


//console.log(set)
result.prototype.sing = function(){
    console.log('会唱歌')
}

module.exports = result
