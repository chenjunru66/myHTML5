/**
 * Created by Administrator on 2016/10/10.
 */
var ser = require('./ser')
var result = new ser('li', 10)
result.run()
result.sing()