//nodejs环境中，一个Js文件，可称之为模块，多个js文件放置在文件夹中，该文件夹称之为模块包
//当前模块 A 如果想调用另一个模块  B，需要引入模块(require)
// A 导入 （require） 模块B
// B 通过module.exports导出模块A所需要的东西
var show = function(name, age){
    this.name = name
    this.age = age
    this.run  = function(){
        console.log( name + '已经' + age + '岁了，会跑步' )
    }
}
module.exports = show
//var set = new show('yan', 20)
//set.run()