var express = require('express'),
    bodyParser = require('body-parser')

var app = express()


app.use(express.static('www'))
app.use(bodyParser.urlencoded({extended:false}))

//数据添加模块
app.use(require('./routers/add'))

app.listen(2000, function(){
    console.log('mongo is running')
})