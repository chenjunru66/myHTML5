//引入模块
var mongoose = require('mongoose')
// 连接本地某个数据库
mongoose.connect('mongodb://localhost/students')
//找到连接的数据库
var db = mongoose.connection
//设置事件---错误和正确
db.on('error', function(){
    console.log('数据库连接失败')
})
db.once('open', function(){
    console.log('数据库连接成功，打开数据库')
})

// 数据库的各种操作  增删改查
// 数据库  -- 集合  --- 文档
// Schema -- model -- 实例
function save(){
    var stuSchema = mongoose.Schema({
        name:String,
        age:Number,
        isMale:Boolean,
        birth:Date,
        email:String
    })

    //console.log(stuSchema)
    //  创建一个模型(类似生成一个集合，集合的数据类型遵循stuSchema)
    var Student = mongoose.model('students', stuSchema)
    //console.log(Student)
    // 由模型创建实例化对象(类似生成一个文档)
    var stu1 = new Student({
        name:'王思',
        age:18,
        isMale:true,
        email:'1275@qq.com',
        birth:new Date(1977,08,17)
    })
    //console.log(stu1)
    // 保存数据
    stu1.save(function(err, datas){
        if(!err){
            console.log('数据保存成功')
        } else {
            console.log('数据保存失败')
        }
    })
}
//save()

//  查找
function find() {
//    查找数据(文档)---集合中的文档
//     db.collectionName.find()
    var stuSchema = mongoose.Schema({
        name: String,
        age: Number,
        isMale: Boolean,
        birth: Date,
        email: String
    })
    var Student = mongoose.model('students', stuSchema)
    //两种方法
    //Student.find(callback)
    //Student.find().exec(callback)

    //  无条件查询--方法一
    //Student.find(function(err, data){
    //    console.log(data)
    //})
//  find()  -- 查找方法
//  exec() [execute]  --- 执行方法
    //    无条件查询--- 方法二
    //Student.find().exec(function(err, data){
    //    console.log(data)
    //})
// 条件查找   --- 查找符合条件的数据
//    Student.find({age:10}, function(err, data){
//        console.log(data)
//        console.log( typeof data[0]._id)
//    })
//    ---查找条件：age大于等于15小于等于17
//    Student.find({age: {$lte: 17, $gte: 15}}, function (err, data) {
//        console.log(data)
//    })
//   ---- 显示部分数据  ,先按条件查找信息，再选择可显示的数据

    //Student.find({age: {$lte: 18, $gte: 10}}).select('name age').exec(function (err, data) {
    //    console.log(data)
    //})
    // --- 显示一条数据
    //Student.findOne({age: {$lte: 18, $gte: 10}}).exec(function(err,data){
    //    console.log(data)
    //})
//    数据的数量
//    Student.find().count(function(err, data){
//        console.log(data)
//    })
//    根据id值查找数据
//    Student.findById('57fd9aa5c567d906a81f33cd').exec(function(err, data){
//        console.log(data)
//    })
//    升序/降序排列以属性名的正负值判断 正--升序，负---降序
    Student.find().sort('-age').exec(function(err,data){
        console.log(data)
    })
}
//find()

// 更新文档

function update(){
    var stuSchema = mongoose.Schema({
        name: String,
        age: Number,
        isMale: Boolean,
        birth: Date,
        email: String
    })
    var Student = mongoose.model('students', stuSchema)

    //Student.update({age:15}, {age:30, isMale:true}, function(err, data){
    //    console.log(data)
    //})
    //Student.update({age:30}, {age:35}).exec(function(err, data){
    //    console.log(data)
    //})
    //根据Id值更新数据
    //Student.findByIdAndUpdate('57fd99593a70970c50acf843', {age:26}).exec(function(err, data){
    //    console.log(data)
    //})
    //更新所有符合条件的数据
    //Student.update({isMale:false}, {isMale:true}, {multi:true}, function(err,data){
    //    console.log(data)
    //})



}
//update()
//删除方法
function remove(){
    var stuSchema = mongoose.Schema({
        name: String,
        age: Number,
        isMale: Boolean,
        birth: Date,
        email: String
    })
    var Student = mongoose.model('students', stuSchema)

    //删除符合条件的数据
    Student.remove({age:35}).exec(function(err){
        consolo.log('数据删除成功')
    })
    //Student.findByIdAndRemove().exec()
    //Student.findOneAndRemove().exec()
}




