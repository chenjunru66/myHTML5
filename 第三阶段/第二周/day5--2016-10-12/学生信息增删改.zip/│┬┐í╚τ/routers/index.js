var express = require('express')

var router = express.Router()
var Student = require('./studb')

router.get('/',function(req,res){

    Student.find(function(err,data){
        if(!err){
            //data = data.map(function(item){
            //
            //    //模板引擎{{data._id}}无法获取id值
            //    //model对象时复杂型的Object对象
            //    item = item.toObject()
            //    //console.log(item)
            //    item.ids = item._id
            //    console.log(item)
            //    return item
            //})
            //
            //res.send(data)

            res.render('template',{
                title:'管理首页',
                datas:data
            })
            //console.log(data)
        }else{
            console.log(data)
        }


    })

})

module.exports = router