//三个集合：用户信息、提问信息、回答信息
//引入模块
var mongoose = require('mongoose')
//连接本地的某个数据库
mongoose.connect('mongodb://127.0.0.1/questions')
// 找到已连接的数据库
var db = mongoose.connection
// 判断连接的状态 -- 成功/失败
db.on('error', function(){
    console.log('连接失败')
})
db.once('open', function(){
    console.log('连接成功，打开数据库')
})
//判断集合关联的关系
//用户集合：问题，答案，
//问题集合：提问者，答案
//答案集合：回答者，问题

// 创建集合 --- 创建模式--模型---集合实例
//用户的模式
var userSchema = mongoose.Schema({
    username:String,
    password:String,
    isMale:Boolean
})
//用户模型
var userModel = mongoose.Model('users', userSchema)
//问题的模式
var quesSchema = mongoose.Schema({
    content:String,
    time:Date,
    createUser:{
        type:mongoose.Schema.ObjectId,
        ref:'users'
    },
    //  一个问题多个答案，答案---ObjectId,
    answers:[{
        type:mongoose.Schema.ObjectId,
        ref:'ans'
    }]
})
//问题的模型
var quesModel = mongoose.Model('ques', quesSchema)
// 答案的模式
var ansSchema = mongoose.Schema({
    content:String,
    time:Date,
    createUser:{
        type:mongoose.Schema.ObjectId,
        ref:'users'
    },
    asks:{
        type:mongoose.Schema.ObjectId,
        ref:'ques'
    }
})
//答案的模型
var ansModel = mongoose.Model('ans', ansSchema)