/**
 * Created by Administrator on 2016/10/24.
 */
alert('b is runing')
//show('yan', 15)