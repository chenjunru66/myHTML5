/**
 * Created by Administrator on 2016/10/24.
 */
//console.log(a)
alert('c is runing')