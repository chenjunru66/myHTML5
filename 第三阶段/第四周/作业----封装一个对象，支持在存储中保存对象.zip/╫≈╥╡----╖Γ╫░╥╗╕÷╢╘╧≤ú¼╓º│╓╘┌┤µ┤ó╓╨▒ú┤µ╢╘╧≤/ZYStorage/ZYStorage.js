ZYStorage = {
    session: function(name, value){
        
    },
    removeSession: function(name){
        
    },
    local: function(name, value){
        
    },
    removeLocal: function(name){
        
    }
}