// ====each:遍历=========
// var arr = [1,23,3,45]
// // para1:需要被遍历对象
// // para2：迭代函数
// // para3:可选的，this的指向
// _.each(arr,function(ele,index,list){
//     console.log(ele)
//     console.log(index)
//     console.log(list)
//     console.log(this)
// },arr)

// var obj = {
//     name:'lucy',
//     age:20,
//     sex:'female',
//     sayhello:function(){
//         console.log('helloworld!!')
//     }
// }

// _.each(obj,function(value,key,list){
//     console.log(value)
//     console.log(key)
//     console.log(list)
// })

// ======reduce:聚合==========
// var arr = [10,100,20,30]
// var result = _.reduce(arr,function(memo,value,index,list){
//     console.log(memo)
//     console.log(value)
//     console.log(index)
//     console.log(list)
//     return memo + value
// },0)
// console.log(result)
//   memo      value        index   return
//   0           10          0        10  
//   10          100         1        110
//   110         20          2        130
//   130         30          3        160

// result = 160 

// ======predicate:谓词==============
// // predicate:谓词，表示判断；填写查找条件，会获取满足条件的数据
// var arr = [10,21,3,4,5,6,7,8]
// // 从数组中获取满足条件的第一个数据，返回
// var result = _.find(arr,function(value){
//     console.log(value)
//     // if(value %3 == 0){
//     //     return true
//     // }
//     // return false

//     return value%3==0
// })
// console.log(result)

// ======where=================
// where:遍历数组中的元素，返回包含指定属性的元素构成的新数组
// var arr = [
//     {name:'xiaoMing',age:20,sex:true},
//     {name:'xiaoHong',age:22,sex:false},
//     {name:'xiaoQing',age:20,sex:false},
//     {name:'xiaoBai',age:20,sex:true}
// ] 
// var result = _.where(arr,{age:20,sex:true})
// console.log(result)

// ======invoke:唤醒、执行=========
// //arguments:是函数中内置的一个局部变量，
// // 通过这个对象可以获取调用方法时
// // 传递的每一个参数，以及参数的数目，还有所在函数；
// function test(a,b){
//     console.log(a  + '---' + b)
//     console.log(arguments)
//     console.log(arguments.length)
//     console.log(arguments[0])
//     console.log(arguments.callee)
// }
// test(1,2)

// var result = _.invoke([[5, 1, 7], [3, 2, 1]], 'sort')
// console.log(result)

// -------toArray:转化为数组=========
// function test(a,b,c,d){
//     var result = _.toArray(arguments)
//     console.log(arguments)
//     console.log(result)
// }
// test(16,21,3,4)


// ==============bindAll=======
// 
// var stu = {
//     sayHello:function(){
//         console.log(this)
//     }
// }
// // 固化sayHello中this永远为stu
// _.bindAll(stu,'sayHello')
// 如果不要105行，点击按钮时，输出的this是button对象
// $('button').on('click',stu.sayHello)

// =============property=======
// var stu = {
//     name:'lucy',
//     age:20
// }
// var func = _.property('age')
// var result = func(stu)
// console.log(result)

// ===========_.template============
// underscore模板化
// 
// var a = 'hello,<%= name %><p>你今年几岁了？</p><p>我<%= age %>岁了</p>'

// //传入模板字符串得到模板编译函数
// var compile  = _.template(a)
// // 传入数据，调用模板编译函数 得到html字符串
// var html = compile({name:'lucy',age:20})
// console.log(html)

// =============underscore链式调用==========
var lyrics = [
  {line: 1, words: "I'm a lumberjack and I'm okay"},
  {line: 2, words: "I sleep all night and I work all day"},
  {line: 3, words: "He's a lumberjack and he's okay"},
  {line: 4, words: "He sleeps all night and he works all day"}
];
/*
[
    [I'm,a,lumberjack,and,I'm,okay],
    [I,sleep,all,night,and,I,work,all,day],
    [,,,,,,,],
    [,,,,,,]
]


[I'm,a,lumberjack,and,I'm,okay,I,sleep,all,night,and,I,work,all,day,,,,,,,,,,,,,]

{I'm:2,lumberjack:1,and:1......}

//{ I'm: 2, a: 2, lumberjack: 2, and: 4, okay: 2, I: 2, sleep: 1, all: 4, night: 2, work: 1,works:1}
*/ 
var result = _.chain(lyrics)
  .map(function(line) { return line.words.split(' '); })
  .flatten()
  .reduce(function(counts, word) {
    counts[word] = (counts[word] || 0) + 1;
    return counts;
  }, {})
  .value();
  console.log(result)











// $('div').text()
// function text(){
//     if(arguments.length ==0){
//         return document.getElementById().innerHtml
//     }else{
//         document.getElementById().innerHtml = arguments[0]
//     }
// }

// a输出应该是多少
// var a = 10 
// function test(a){
//     a++
//     console.log(a)
// }
// test(a)
// console.log(a)

 //防止xss攻击（cross site script 跨域脚本攻击）
     //正则表达式，匹配info中所有的<，替换为&lt;
     ///匹配内容/g  g:global，全局匹配
    //  info = info.replace(/</g,'&lt;')
    //  info = info.replace(/>/g,'&gt;')