// const:常量，初始化之后，不会再修改
// var:变量；没有块级作用域
// let:变量；建议用let取代var；添加了块级作用域，大括号中声明的变量大括号外不能使用

const exp = require('express'),
    bodyParser = require('body-parser')
const app = exp()

// 客户端发过来的是json数据，采用json（） 解析
// 客户端发过来的是key=value&key=value形式的数据，采用
// urlencoded()解析
app.use(bodyParser.json())

app.use(exp.static('www'))

app.post('/remind',(req,res)=>{
    console.log(req.body)
    //把数据保存到数据库....
})

app.listen(3000,()=>{
    console.log('服务器监听3000端口')
})
