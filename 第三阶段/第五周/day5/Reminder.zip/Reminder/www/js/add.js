// --视图类
var Add = Backbone.View.extend({
    el:'body',
    events:{
        'submit form':'submit'
    },
    // 初始化方法
    initialize:function(){
        // 监听模型的invalid事件
        this.listenTo(this.model,'invalid',this.warning)
    },
    warning:function(model,error,options){
        console.log('warning')
        //提示用户
        // error参数 以及model.validationError均为validate方法的返回值
        this.$('*').removeClass('error')
        // jquery....
        this.$('[name=' + error.attr + ']').addClass('error').attr('title',error.message).focus()

    },
    submit:function(ev){
        // 在视图中方法调用的内部this指向的是当前视图
        console.log(this)
        ev.preventDefault()
        //从页面上获取数据
        var data = this.$('form').serializeArray()
        // 把数据写到model中
        this.model.setDataToModel(data)
        //保存数据
        // 保存数据之前会自动调用模型类的validate方法进行数据校验，
        // 校验不通过save方法不会继续执行,同时会触发invalid事件
        // 可以去监听invalid事件，提示用户
        // 注意：需要填写服务器路径,否则不知道保存到哪里
        this.model.save() 
    }
})

// ---模型类
var Remind = Backbone.Model.extend({
    //设置模型在服务器的路径
    urlRoot:'/remind',
    defaults:{
        title:'',
        content:'',
        date:null
    },
    //作用：数据校验
    validate:function(attrs,options){
        console.log('进行数据校验')
        if(!attrs.title || attrs.title==''){
            // 校验失败，返回错误信息
            return {attr:'title',message:'备忘标题不能为空'}
        }
        if(!attrs.content || attrs.content.length<10){
            return {attr:'content',message:'备忘详情不能少于10个字'}
        }
    },
    // 把数组数据填充到模型中
    setDataToModel:function(data){
        // 把数组转化为key-value构成的对象
        data = data.reduce(function(memo,value,index,arr){
            memo[value.name] = value.value
            return memo
        },{})
        console.log(data)
        // 补充日期
        data.date = new Date()
        //把数据保存在模型中
        this.set(data)
    }
})



// 新建视图对象，关联数据模型
new Add({model:new Remind()})