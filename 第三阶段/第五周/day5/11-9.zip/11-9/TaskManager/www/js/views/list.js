// 定义展示任务的视图类
define([
    'backbone','template','jquery','jquery-ui'
], function(B,T,$) {
    return B.View.extend({
        el:'section',
        events:{
            'click label':'changeCompleteState'
        },
        changeCompleteState:function(ev){
            console.log('----click')
            //修改这条数据的complete字段
            // 找到点击的label对应的input的id
            var label = ev.currentTarget
            var id = this.$(label).prev().attr('id')
            console.log(id)
            //找到id对应的数据
            var task = this.model.find(function(item){
                    return item.get('id') == id
            })
            console.log(task)
            // 根据input是否选中修改这条数据的complete
            // (注意：attr 与 prop 获取属性值的区别)
            var complete = this.$(label).prev().prop('checked')
            task.set({complete:!complete})
            //把修改保存到服务端
            task.save()
        },
        initialize:function(){
            this.render()
            // 监听add事件，重新渲染页面
            this.listenTo(this.model,'add',this.render)
            
            // 设置排序
            this.$('ul').sortable({
                // 设置占位符；值是占位li的样式类
                placeholder:'placeholder',
                start:function(){
                    console.log('开始排序了')
                    $('footer>span')
                    .removeClass('icon-plus-sign icon-4x')
                    .addClass('icon-trash icon-4x')
                },
                stop:function(){
                    console.log('结束排序了')
                    $('footer>span')
                    .removeClass('icon-trash icon-4x')
                    .addClass('icon-plus-sign icon-4x')
                },
                // 与另一个区域产生联系，可以跨区域排序
                // (注意：另一个区域也要支持排序)
                // 值:另一个区域的选择器
                connectWith:'footer',
                // 保存排序的位置
                // 只修改移动的数据A的index，其他数据的index不变
                //如果A跑到ul的外面，就无操作；
                //如果A在ul的内部，有如下三种情况：
                //1）如果A移动到最上面，index修改为A下面的数据的index-1
                //2）如果A移动到中间，index修改为A上下两个数据的index的和取平均
                //3）如果A移动到最下面，index就修改为A上面的数据的index+1
               
                // 当被移动元素重新放在一个位置时，会触发的事件
                // para1：事件对象
                // ui:事件涉及到的界面元素；
                // 其中有item属性，是一个jquery对象
                update:function(event,ui){
                    console.log('调整顺序了')
                    console.log(arguments)
                    // 找到被移动的元素
                    var li = ui.item 
                    // 移动到ul的外面了，无操作
                    if(li.parent()[0]!= this.$('ul')[0]){
                        return 
                    }
                    // 找到当前数据，然后修改index
                    var currentId = li.find('input').attr('id')
                    var task = this.model.find(function(item){
                        return item.get('id') == currentId
                    })
                    // 记录当前数据的索引
                    var index 
                    // 移动到最上面
                    if(li.index()==0){
                        console.log('移动到最上面了')
                        var nextIndex = this.getIndex(li.next())
                        // 当前数据的index
                        index = nextIndex - 1 
                    }
                    // 移动到中间
                    if(li.index()>0 && li.index()<this.$('ul li').length-1){
                        console.log('移动到中间了')
                        // 上一个数据的index
                        var prevIndex = this.getIndex(li.prev())
                        // 下一个数据的index
                        var nextIndex = this.getIndex(li.next())
                        index = (prevIndex + nextIndex )/2
                    }
                    // 移动到最下面
                    if(li.index() == this.$('ul li').length-1){
                        console.log('移动到最下面')
                        // 上一个数据的index
                        var prevIndex = this.getIndex(li.prev())
                        index = prevIndex + 1
                    }
                    // 修改这条数据的index
                    task.set('index',index)
                    // 保存 
                    task.save()
                }.bind(this)
                
            })
        },
        //找到某个li对应的数据的id
        //参数：li的jquery对象
        // 返回值是 id
        getIndex:function(ele){
            //找到标签对应的任务数据
            var task = this.model.find(function(item){
                return item.get('id') == ele.find('input').attr('id')
            })
            return task.get('index')
        },
        render:function(){
            console.log('监听到changeDate事件了')
            // 获取当前日期的数据，展示
            console.log('初始化')
            this.model.fetch().done(function(){
                console.log(this.model.toJSON())
                //展示页面
                var html = T('list',{arr:this.model.toJSON()})
                console.log(html)
                this.$('ul').html(html)

            }.bind(this)).fail(function(error){
                alert('请尝试再次刷新页面！！')
            })
        }
    })
})