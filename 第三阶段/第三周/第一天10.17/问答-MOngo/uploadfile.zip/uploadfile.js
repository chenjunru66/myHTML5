var express = require('express'),
    bodyParser = require('body-parser'),
    multer = require('multer')
    
var router = express.Router()

var storage = multer.diskStorage({
    destination:'www/uploads',
    filename:function(req,file,callback){
        var username = req.cookies.username
        callback(null,username + '.jpg')
    }
}),
uploads = multer({storage})

router.use(bodyParser.urlencoded({extended:false}))

router.post('/user/photo',uploads.single('photo'), function(req, res){
    res.status(200).json({code:'success', message:'上传成功'})
})
module.exports = router