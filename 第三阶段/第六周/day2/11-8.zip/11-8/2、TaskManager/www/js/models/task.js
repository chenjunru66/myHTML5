// 定义任务模型
define([
    'backbone'
], function(B) {
    return B.Model.extend({
        defaults:{
            // 任务内容
            content:'',
            // 任务时间 '20161108'
            time:'',
            // 任务是否完成
            complete:false,
            //任务的顺序
            index:0
        }
    })
    
})