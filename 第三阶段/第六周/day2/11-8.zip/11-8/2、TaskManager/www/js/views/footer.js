// 定义footer视图类
define([
    'backbone'
], function(B) {
    return B.View.extend({
        el:'footer',
        initialize:function(){
            
        },
        events:{
            // 点击加号
            'click span':'showEditBox',
            // 点击提交按钮
            'click button':'commit'
        },
        showEditBox:function(){
            this.$('#editBox').show()
            this.$('span').hide()
        },
        commit:function(){
            this.$('span').show()
            this.$('#editBox').hide()
            //提交数据content
            var content = this.$('input').val()
            // 清空输入框
            this.$('input').val('')
            // 从共享数据中获取时间this.shareData.date
            var date = this.shareData.date
            // '20161108' = 2016*10000 +  11 *100 + 8 + ''
            var time =  date.getFullYear()*10000 + (date.getMonth()+1)*100 + date.getDate() + ''
            console.log(time)
            var complete = false
            // 获取当前数据对应的序号
            // 从数据库中获取当前日期的所有数据，最后一条数据的index加1就是这条数据的index
            var index = 0
            this.model.fetch()
            .done(function(data){
                console.log(data)
                if(data.result == 1){
                    // 如果数组中有数据
                    if(data.data.length > 0){
                        // 数组中最后一条数据的index值
                        var length = data.data.length
                        index = data.data[length-1].index
                    }
                    // 当前数据的index
                    index ++ 
                    // 保存数据
                    // create方法会根据填入的参数，新建模型对象
                    // 模型创建成功会添加到集合中
                    // 同时保存数据到服务端
                    this.model.create({
                        content:content,
                        time:time,
                        complete:complete,
                        index:index
                    })
                }
            }.bind(this)).fail(function(error){

            })
        }
    })
})
