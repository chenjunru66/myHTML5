// 定义展示任务的视图类
define([
    'backbone'
], function(B) {
    return B.View.extend({
        el:'section',
        events:function(){

        },
        initialize:function(){
            // 
            // 获取当前日期的数据，展示
            console.log('初始化')
            this.model.fetch().done(function(){
                console.log(this.model)
                //渲染页面
            }.bind(this)).fail(function(error){
                alert('请尝试再次刷新页面！！')
            })

            console.log(this.model)
            // 监听changeDate事件，监听到，重新渲染页面
            this.listenTo(this.model.shareData,'changeDate',this.render())
        },
        render:function(){
            console.log('监听到changeDate事件了')
        }
    })
})