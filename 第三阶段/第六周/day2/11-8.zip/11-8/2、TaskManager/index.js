const exp = require('express'),
    bodyparser = require('body-parser'),
    Task = require('./db.js')
const app = exp()
app.use(exp.static('www'))
app.use(bodyparser.json())

// 查询数据
app.get('/tasks/:time',(req,res)=>{
    var time = req.params.time
    console.log(time)
    // 查询获取该日期下的数据，返回客户端
    Task.find({time:time}).then(function(data){
        res.json({result:1,data:data})
    }).catch(function(error){
        res.json({result:0,message:error.message})
    })
})

// 保存数据
app.post('/tasks/:time',(req,res)=>{
    var task = new Task(req.body)
    task.save().then(function(){
        res.json({result:1,message:'保存数据成功'})
    }).catch(function(error){
        res.json({result:0,message:error.message})
    })
})


app.listen(4000,()=>console.log('服务端监听4000端口'))