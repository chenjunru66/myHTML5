define([
    'backbone','template'
], function(B,T) {
    // 日期格式化的辅助函数
    T.helper('dateToString',function(date){
        console.log('辅助函数')
        date = new Date(date)
        var year = date.getFullYear()
        var month = date.getMonth()+1
        var day = date.getDate()

        var hour = date.getHours()
        var minute = date.getMinutes()
        var second = date.getSeconds()
        return year + '年' + month + '月' + day + '日' + '  ' + hour + ':' + minute + ':' + second
    })
    return B.View.extend({
        el:'body',
        render:function(){
            console.log(typeof this.model.models)
            console.log(this.model.toJSON())
            // this.model.toJSON() 返回集合中包含的每个模型(通过 toJSON) 的属性构成的数组；
            // 模板插值，获取html字符串
            var html = T('reminds',{arr:this.model.toJSON()})
            console.log(html)
            // 填充页面
            this.$('main').html(html)
        },
        initialize:function(){
        
            this.model.fetch().done(function(data){
                // 渲染页面
                this.render()
            }.bind(this)).fail(function(error){
                console.log(arguments)
                alert('请尝试再次刷新页面')
            })
        }
    })
})