// require配置
require.config({
    // 说明模块路径(相对于当前js文件的路径)
    paths:{
        'jquery':'libs/jquery',
        'underscore':'libs/underscore',
        'backbone':'libs/backbone-min',
        'template':'libs/template',
        'localstorage':'libs/backbone.localStorage-min'
    },
    // 说明依赖关系；
    shim:{
        'backbone':['underscore','jquery'],
        'localstorage':['backbone']
    }
})

require(['views/index','collections/reminds'],function(Index,Reminds){
    var reminds = new Reminds()
    new Index({model:reminds})
})