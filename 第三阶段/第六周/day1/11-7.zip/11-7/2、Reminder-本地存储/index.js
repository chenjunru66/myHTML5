// const:常量，初始化之后，不会再修改
// var:变量；没有块级作用域
// let:变量；建议用let取代var；添加了块级作用域，大括号中声明的变量大括号外不能使用

const exp = require('express')
const app = exp()


app.use(exp.static('www'))


app.listen(3000,()=>{
    console.log('服务器监听3000端口')
})
