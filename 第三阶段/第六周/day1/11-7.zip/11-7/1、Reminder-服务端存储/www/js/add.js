// require配置
require.config({
    // 说明模块路径(相对于当前js文件的路径)
    paths:{
        'jquery':'libs/jquery',
        'underscore':'libs/underscore',
        'backbone':'libs/backbone-min'
    },
    // 说明依赖关系；
    shim:{
        'backbone':['underscore','jquery']
    }
})
require(['models/remind','views/add'],function(Remind,Add){
    // 新建视图对象，关联数据模型
    new Add({model:new Remind()})
})

