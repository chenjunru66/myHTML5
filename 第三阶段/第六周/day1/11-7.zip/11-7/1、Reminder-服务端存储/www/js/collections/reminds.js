define([
    'backbone','../models/remind'
], function(B,Remind) {
    // 定义集合类
    return B.Collection.extend({
        model:Remind,
        // 设置路径
        url:'/reminds',
        // parse:解析；
        // 每次调用fetch从服务端拉取数据的时候，会自动调用parse方法
        // parse方法的参数是服务端返回的数据
        // parse方法的返回值是 可以添加到集合的模型属性数组
        // backbone内部会接收parse方法的返回值，生成一个个的model对象
        // 然后添加到集合中
        // 例如 :
        // [
        //  {content:'内容',title:'标题',date:new Date()},
        //  {content:'内容',title:'标题',date:new Date()}
        // ]
        parse:function(data){
            console.log('数据解析')
            console.log(data)
            return data.data
        }
    })
})